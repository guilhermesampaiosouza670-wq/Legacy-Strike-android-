# Legacy Strike CS2 — começar pelo celular Android

Este pacote contém o projeto Android e um workflow para o GitHub Actions. **Ele ainda não contém um APK compilado.** A compilação acontece nos servidores do GitHub, não dentro do celular.

## Passo 1 — criar o repositório

1. Abra https://github.com/ no Chrome e entre na sua conta.
2. Toque em **+** e depois em **New repository**.
3. Dê o nome `LegacyStrike-Android-v1.1` e toque em **Create repository**.
4. No repositório, use **Add file > Upload files**.

## Passo 2 — enviar os arquivos certos

1. No celular, extraia `LegacyStrike-Android-v1.1.zip` com um gerenciador de arquivos.
2. Entre na pasta extraída `LegacyStrike-Android-v1.1`.
3. Envie **o conteúdo dessa pasta** para a raiz do repositório GitHub. Não envie apenas o ZIP e não crie uma pasta extra dentro do repositório.
4. Ative “mostrar arquivos ocultos” no gerenciador de arquivos e confirme que a pasta `.github` também foi enviada.
5. Antes de confirmar, confira se aparecem na raiz `app`, `.github`, `build.gradle`, `settings.gradle` e `gradle.properties`.
6. Toque em **Commit changes**.

## Passo 3 — iniciar a compilação

1. No repositório, abra a aba **Actions**.
2. Se aparecer uma mensagem para habilitar workflows, toque em **I understand my workflows, go ahead and enable them**.
3. Escolha **Build APK** na lista à esquerda.
4. Toque em **Run workflow** e confirme em **Run workflow**.
5. Abra a execução que aparecer e aguarde. O processo pode demorar alguns minutos porque instala as ferramentas e dependências Android.

## Passo 4 — baixar e instalar

1. Se a execução terminar com marca verde, abra a execução.
2. Desça até **Artifacts**.
3. Baixe `LegacyStrike-debug-apk`.
4. Extraia o ZIP baixado e abra `app-debug.apk`.
5. Se o Android bloquear, permita a instalação de aplicativos desconhecidos para o navegador ou gerenciador de arquivos usado.
6. Instale e teste o jogo.

## Se ficar vermelho

1. Abra a execução vermelha.
2. Abra o passo que falhou e copie o erro completo, principalmente as últimas linhas.
3. Se existir o artifact `LegacyStrike-build-log`, baixe-o e envie o arquivo ou o texto aqui.
4. Não apague nem altere arquivos aleatoriamente: o log mostra qual etapa falhou.

## Observações

- O APK Debug é o indicado para o primeiro teste.
- O APK Release sem uma chave própria usa assinatura de debug e serve apenas para testes; não é a versão definitiva para publicar.
- O modelo `bruh_im_dead.glb` não veio no ZIP. O projeto contém uma nota indicando isso; o jogo usa o monstro procedural alternativo. Não invente nem substitua esse modelo sem o arquivo correto.
- Testes no navegador não comprovam funcionamento em aparelho físico. Bluetooth, áudio, desempenho, sensores e multiplayer ainda precisam ser testados no celular.
