# Auditoria do projeto

**Arquivo:** `Legacy_Strike_CS2.html`, único, ~17,6 MB, ~8,9 mil linhas, 25 blocos `<script>`; Three.js, modelos esqueléticos (`__CSMD`), vídeos e texturas embutidos em base64.

## Já existia (preservado, não recriado)
- Controles touch (joystick, FOGO/PULAR/RECARR./ZOOM/TROCAR/GRANADA/COMPRA/AÇÃO/SOLTAR/BOTS/MENU) e editor de layout.
- Gamepad completo + mouse virtual + mira assistida (ver GAMEPAD.md).
- Presets gráficos Muito baixo, Baixo, Médio, Alto, Muito alto, Ultra, com benchmark automático (`navigator.hardwareConcurrency`, `deviceMemory`, FPS).
- Tela cheia, salvamento em `localStorage` (`ls_*`), exportar/importar save, música local, multiplayer por WebSocket opcional.

## Problemas encontrados e correções
| Problema | Correção |
|---|---|
| Única dependência externa: Google Fonts (quebra o "offline") | Removida no build do app; fontes caem para `system-ui` |
| Fullscreen API e `screen.orientation.lock` não funcionam no WebView | Emulados na camada Android (app já é imersivo e horizontal) |
| Exportar save via `<a download>`/blob não funciona no WebView | Interceptado → seletor "Salvar como" do Android |
| Seletor de arquivos (importar save, música) não funciona no WebView por padrão | `onShowFileChooser` implementado |
| `AudioContext` suspenso no Android até haver gesto | Retomado em qualquer toque/tecla; suspenso em segundo plano |
| "Xbox Wireless Controller" era detectado como PlayStation (dicas ✕○□△ erradas) | Regex corrigida |
| Mouse virtual do gamepad só aparecia com o analógico direito; D-pad desligava o cursor | Cursor automático nos menus, ambos os analógicos movem, D-pad leva o cursor ao botão |
| Arma flutuando no personagem do menu | Mãos resolvidas por IK até a arma; personagem apoiado no chão |
| Renderer do WebView pode ser morto por falta de RAM | `onRenderProcessGone` recria a tela; `largeHeap` |
| Perda de contexto WebGL | `preventDefault` + redimensionamento na restauração |

## Limites conhecidos (honestos)
- O APK **não foi compilado nem testado em aparelho real** neste ambiente (sem Android SDK/rede). O jogo adaptado foi testado no Chromium com emulação de celular (toque, UA Android, ponte nativa simulada): sem erros de JS, gamepad, backup, exportação, Voltar e pausa funcionando. A casca Java passou na checagem de sintaxe, mas a primeira compilação real pode pedir ajustes pequenos.
- O HTML tem 17 MB e vídeos em base64: a 1ª abertura leva alguns segundos em aparelhos fracos.
- Sem fontes do Google offline, o texto usa a fonte do sistema.

## Atualização (revisão do código)
Ver `RELATORIO.md` para a lista completa de correções e do que foi (e não foi) testado. Ainda **não há APK compilado**; a compilação é feita pelo GitHub Actions (`INSTALAR_E_COMPILAR.md`).


## Revisão aplicada nesta versão (1.1)
- Conquistas renomeadas com objetivos mais claros e consistentes em português.
- Notificação visual de conquista desbloqueada adicionada, com fila de avisos e região acessível (`aria-live`).
- Corrigida a avaliação da conquista de nível: o nível considera também o XP das missões concluídas na partida atual.
- A conquista de 10 skins é conferida novamente depois das recompensas da partida, para não atrasar o desbloqueio quando a décima skin vem no drop.
- Adicionada auditoria automática na inicialização para conferir em cada mapa os dois pontos A/B, coordenadas dentro dos limites e dados básicos das peças de cenário. O resultado fica disponível em `window.__lsMapAudit` e é escrito no console.
- Mantida a correção de bombsites v18 já presente no código: a C4 só pode ser plantada na área A/B; os sites são identificados como A e B e podem ser reposicionados se o cenário bloquear a área.
- Versão Android atualizada para `versionCode 2` / `versionName 1.1`.

## Validação desta revisão
- Os 25 blocos JavaScript embutidos passaram por `node --check` (verificação sintática).
- O APK não foi compilado: este ambiente não possui Android SDK nem Gradle instalado. O pacote mantém o workflow GitHub Actions para gerar os APKs debug e release.
- A auditoria A/B foi adicionada para executar no próprio jogo; não afirmo teste de partida em aparelho real nesta sessão.
