# Legacy Strike CS2 — Android (APK)

**Versão do pacote: 1.1** — inclui notificações de conquistas, nomes revisados, correção da progressão de nível e auditoria automática dos bombsites A/B.

Projeto Android completo (WebView nativo + `WebViewAssetLoader`) que empacota o jogo **inteiro e sem alterações de regras**
em `app/src/main/assets/www/index.html`. Funciona 100% offline.

## Gerar o APK

### Opção A — Android Studio (mais simples)
1. Instale o Android Studio (Koala ou mais novo). 
2. `File > Open` e escolha esta pasta (`LegacyStrike-Android`). Aguarde o *Gradle Sync* (precisa de internet na 1ª vez).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale
   (ative "Instalar apps desconhecidos"). Ou conecte o celular por USB (Depuração USB) e clique em **Run ▶**.

### Opção B — Linha de comando
Requer JDK 17, Android SDK (plataforma 34 + build-tools) e Gradle 8.7+:
```bash
export ANDROID_HOME=$HOME/Android/Sdk          # ajuste
gradle wrapper --gradle-version 8.7            # gera ./gradlew e gradle-wrapper.jar (uma vez; o ZIP não os traz)
./gradlew assembleDebug assembleRelease        # APKs de teste e release
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Opção C — Sem instalar nada (GitHub Actions)
Passo a passo completo (feito para quem só tem o celular): **`INSTALAR_E_COMPILAR.md`**. Resumo: envie a pasta ao GitHub, rode *Actions > Build APK*
e baixe `LegacyStrike-debug-apk` / `LegacyStrike-release-apk` em *Artifacts*.

### APK de lançamento (assinado)
```bash
keytool -genkey -v -keystore legacystrike.jks -keyalg RSA -keysize 2048 -validity 10000 -alias legacystrike
```
Crie `keystore.properties` na raiz:
```
storeFile=legacystrike.jks
storePassword=SUA_SENHA
keyAlias=legacystrike
keyPassword=SUA_SENHA
```
e rode `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.
Sem chave própria o release sai assinado com a chave de DEBUG (instala, mas só serve para teste). No GitHub Actions use os secrets `LS_KEYSTORE_*` (ver `INSTALAR_E_COMPILAR.md`).

## Atualizar o jogo dentro do APK
Se você editar o HTML original, regenere o arquivo do app:
```bash
python3 tools/make_index.py caminho/Legacy_Strike_CS2.html
```
(só aplica: viewport sem zoom, `android-adapt.js` carregado primeiro, remove Google Fonts, corrige detecção do controle Xbox).

## O que o app faz
| Requisito | Como |
|---|---|
| Offline | Tudo em `assets/www`; nenhuma dependência externa (Three.js, modelos, vídeo e sons já estão no HTML). O link do Google Fonts foi removido; as fontes caem para `system-ui`. |
| Horizontal + tela cheia | `sensorLandscape`, modo imersivo fixo, tela sempre ligada, suporte a *notch*. O jogo recebe a Fullscreen API como "já ativa". |
| Progresso e configurações | `localStorage` numa origem fixa (`appassets.androidplatform.net`) **+ espelho em arquivo nativo** (`filesDir/ls_backup.json`) restaurado se o armazenamento do WebView vier vazio. |
| Exportar/importar save | Exportar abre o seletor de arquivos do Android ("Salvar como"); importar e música usam o seletor nativo. |
| Gráficos | O jogo já traz Muito baixo / Baixo / Médio / Alto / Muito alto / Ultra (⚙ > Gráficos), com benchmark automático no 1º uso. Mantive todos. |
| Áudio | `mediaPlaybackRequiresUserGesture=false`, `AudioContext` retomado no 1º toque e suspenso em segundo plano. |
| Desempenho | Aceleração por hardware, `largeHeap`, perda de contexto WebGL tratada, recriação automática se o renderer do WebView for encerrado por falta de memória, timers pausados em segundo plano. |
| Botão Voltar | Fecha loja/painéis → pausa → menu inicial → "toque de novo para sair". Ao ir para segundo plano durante a partida, pausa sozinho. |
| Toque | Sem zoom/seleção/menu de contexto/pull-to-refresh; área de toque dos botões ampliada em 9 px sem mudar o layout; o editor "Layout" do jogo continua funcionando. |
| Gamepad | Ver `GAMEPAD.md`. |
| Permissões | `INTERNET` (multiplayer opcional), `ACCESS_NETWORK_STATE`, `VIBRATE`. Nenhuma de armazenamento (usa o seletor do sistema). |

## Teste em aparelho (checklist)
1. Abre em horizontal, sem barras do sistema; menu e vídeo de intro carregam.
2. ⚙ > Gráficos: trocar de preset e ver o FPS.
3. Jogar: joystick à esquerda, olhar arrastando à direita, FOGO/PULAR/RECARR./ZOOM/TROCAR/GRANADA/COMPRA/MENU.
4. Fechar o app e reabrir: moedas, skins e configurações continuam.
5. Modo avião: o jogo abre e joga normalmente.
6. Conectar controle Bluetooth: dicas de botões aparecem e o menu responde (ver `GAMEPAD.md`).
7. `adb logcat -s LegacyStrike` mostra o console do jogo (build debug).

## Estrutura
```
app/src/main/AndroidManifest.xml
app/src/main/java/com/legacystrike/cs2/MainActivity.java   WebView, ponte JS, gamepad nativo, Voltar, imersivo
app/src/main/assets/www/index.html                        jogo completo
app/src/main/assets/www/android-adapt.js                  camada de adaptação (carregada primeiro)
tools/make_index.py                                       regenera index.html a partir do HTML original
.github/workflows/build-apk.yml                           build automático
```
