#!/usr/bin/env python3
"""Gera app/src/main/assets/www/index.html a partir do HTML original do jogo.
Uso: python3 tools/make_index.py caminho/Legacy_Strike_CS2.html
Alterações (só isto): viewport sem zoom, android-adapt.js carregado primeiro, Google Fonts removido (offline)."""
import re, sys, pathlib
src = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
out = pathlib.Path(__file__).resolve().parent.parent / 'app/src/main/assets/www/index.html'
meta_old = '<meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover">'
meta_new = ('<meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">'
            '<meta name="mobile-web-app-capable" content="yes"><meta name="theme-color" content="#0a0b08">'
            '<script src="android-adapt.js"></script>')
assert src.count(meta_old) == 1, 'viewport original não encontrado'
src = src.replace(meta_old, meta_new)
src, n = re.subn(r'<link rel="stylesheet" media="print" onload="this.media=\'all\'" href="https://fonts\.googleapis\.com[^>]*>', '', src)
print('fontes externas removidas:', n)
# correção: "Xbox Wireless Controller" era detectado como PlayStation (regex "wireless controller")
old = "/054c|dualsense|dualshock|playstation|wireless controller/i.test(g.id)?'ps':'xbox'"
new = "(/054c|dualsense|dualshock|playstation|wireless controller/i.test(g.id)&&!/xbox|045e/i.test(g.id))?'ps':'xbox'"
assert src.count(old) == 1, 'layoutOf não encontrado'
src = src.replace(old, new)
out.write_text(src, encoding='utf-8')
print('gerado', out, len(src)//1024, 'KB')
