# Legacy Strike CS2 — instalar o APK e compilar pelo celular

## 1) Instalar o APK no Android
1. Baixe o arquivo `.apk` (do GitHub Actions, ver seção 3) e abra-o pelo app **Arquivos/Downloads**.
2. Se o Android pedir, permita "Instalar apps desconhecidos" para o app que você usou (Chrome, Arquivos...).
3. Toque em **Instalar**. Abra **Legacy Strike CS2** (o jogo abre em tela cheia, na horizontal).
- `app-debug.apk` instala como "Legacy Strike CS2" com id `com.legacystrike.cs2.debug` (pode coexistir com o release; os saves de cada um são separados).
- `app-release.apk` usa o id `com.legacystrike.cs2`. Se foi assinado com a chave de debug (padrão sem secrets), serve só para teste.
- Trocar de assinatura exige desinstalar a versão anterior (perde o save local; use ⚙ > Exportar antes).

## 2) Enviar o projeto ao GitHub só com o celular
1. Entre em github.com pelo navegador (modo "Site para computador") e crie um repositório (**New**), privado ou público.
2. **Add file > Upload files**: o GitHub do celular não aceita ZIP para descompactar. Opções:
   - Instale um app de arquivos que descompacte (ex.: ZArchiver), extraia o ZIP e envie as pastas; **a pasta `.github` precisa subir** (pastas começadas com ponto ficam ocultas: ative "mostrar arquivos ocultos").
   - Alternativa mais simples: GitHub app/Termux com `git` (`git init`, `git add .`, `git commit`, `git push`).
3. O arquivo `app/src/main/assets/www/index.html` tem ~18 MB: o upload pelo navegador aceita até 25 MB por arquivo, então cabe; se falhar, use git/Termux (limite 100 MB por arquivo).
4. Confirme que existem no repositório: `.github/workflows/build-apk.yml`, `app/`, `build.gradle`, `settings.gradle`, `gradle.properties`.

## 3) Compilar e baixar o APK (GitHub Actions)
1. No repositório: aba **Actions** > **Build APK** > **Run workflow** (também roda sozinho a cada push em `main`/`master`).
2. Espere terminar (✔ verde). Se ficar ❌, abra a execução, toque no passo vermelho e me envie o texto do erro.
3. Role até **Artifacts** e baixe `LegacyStrike-debug-apk` e `LegacyStrike-release-apk` (vêm dentro de um ZIP; extraia e instale o `.apk`).
4. O workflow só dá sucesso se os dois APKs existirem (passo "Verificar se os APKs foram criados").

## 4) Gerar novas versões
1. Edite o jogo (`app/src/main/assets/www/index.html`) ou, se tiver o HTML original novo: `python3 tools/make_index.py Legacy_Strike_CS2.html`.
2. Aumente `versionCode` (+1) e `versionName` em `app/build.gradle` (necessário para atualizar por cima).
3. Faça commit/push (ou edite o arquivo direto no GitHub). O Actions compila de novo; baixe o novo artifact.

## 5) APK Release assinado com chave própria (para distribuir)
1. **Actions > Gerar chave de assinatura (uma vez) > Run workflow**, digite uma senha (8+ caracteres).
2. Baixe o artifact `keystore` (contém `legacystrike.jks`, `keystore_base64.txt`, `secrets_para_cadastrar.txt`). **Guarde em local seguro e apague do repositório/Actions depois**: quem tem esse arquivo assina como você.
3. **Settings > Secrets and variables > Actions > New repository secret**, crie 4 secrets:
   `LS_KEYSTORE_BASE64` (conteúdo de `keystore_base64.txt`), `LS_KEYSTORE_PASSWORD` (a senha), `LS_KEY_ALIAS` (`legacystrike`), `LS_KEY_PASSWORD` (a mesma senha).
4. Rode **Build APK** de novo: o passo de assinatura passa a usar a sua chave. Nunca perca essa chave: sem ela não é possível atualizar o app para quem já instalou.

## 6) Compilar no PC (opcional)
JDK 17 + Android SDK 34 + Gradle 8.7: `gradle wrapper --gradle-version 8.7` (cria `gradlew`, uma vez) e `./gradlew assembleDebug assembleRelease`.
Para assinar localmente crie `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword) na raiz.
