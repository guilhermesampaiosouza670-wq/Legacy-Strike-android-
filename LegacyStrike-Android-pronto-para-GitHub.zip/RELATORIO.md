# Relatório — finalização do projeto Android (Legacy Strike CS2)

## O que NÃO foi possível (honestidade)
- **Nenhum APK foi compilado.** O ambiente de trabalho não tem Android SDK, Gradle nem acesso à internet. Por isso **não há APK Debug nem Release neste pacote**; eles saem do GitHub Actions (ver `INSTALAR_E_COMPILAR.md`).
- **Nada foi testado em aparelho real nem com controle Bluetooth real.** O APK nunca rodou.
- `MainActivity.java` foi verificado só quanto à **sintaxe** (javac do JDK 21: sem erros de sintaxe; os únicos erros são "pacote android não existe", esperados sem o SDK). Não foi compilado contra a API Android.
- `gradlew` / `gradle-wrapper.jar` **não puderam ser gerados** (o .jar vem de download). O workflow não precisa deles (usa Gradle 8.7 via `setup-gradle`). Para uso local: `gradle wrapper --gradle-version 8.7`.

## O que foi realmente testado
Chromium headless (emulação de celular Android, 915×412, toque, UA Android, WebGL por software) abrindo o `index.html` com uma ponte `LSAndroid` **simulada**:
- 26 blocos `<script>` + `android-adapt.js`: sintaxe OK; **0 erros de JavaScript** em 12 s de abertura; menu inicial visível, 18 botões de toque, tela cheia emulada.
- Gamepad: `navigator.getGamepads()` devolve o controle "Xbox Wireless Controller" com 17 botões (mapeamento standard) a partir da ponte simulada.
- Backup do progresso: espelha o `localStorage` na ponte.
- Nenhuma requisição externa (única URL no HTML são namespaces XML). Funciona offline.
- Não foi testada uma partida completa, nem multiplayer, nem desempenho (FPS) em celular.

## Erros encontrados e corrigidos
| # | Problema (no código real) | Correção |
|---|---|---|
| 1 | `MainActivity`: `restoreState()` pode retornar `null` (ex.: `recreate()` após o renderer do WebView morrer por falta de RAM) e a tela ficava preta | Se `restoreState` falhar, carrega a URL inicial |
| 2 | `android-adapt.js`: o espelho de backup só comparava somas de tamanhos; mudar uma opção para valor do mesmo comprimento (ex.: `5`→`6`) não era salvo | Assinatura passa a ser um hash do conteúdo (verificado no teste: 1→2 gravações) |
| 3 | Logcat recebia todo `console.log` do jogo também no release (custo e jank) | Só no build debug |
| 4 | `padState()` reconstruía um JSON com 21 `String.format` a cada leitura do gamepad (alocação/calor) | Cache; só reconstrói quando o estado do controle muda |
| 5 | Nada tratava pouca memória do sistema | `onTrimMemory` chama `window.__lsLowMemory(nível)` se o jogo definir (hoje o jogo não define: gancho pronto, sem efeito ainda) |
| 6 | Release saía **sem assinatura** quando não havia `keystore.properties` (APK não instala) | Usa keystore (arquivo ou `LS_KEYSTORE_*`); sem chave, assina com debug para teste, com aviso |
| 7 | Workflow: só debug, sem verificar APK, rodava em qualquer push | Debug + Release, instala SDK 34, verifica APKs e `index.html` dentro do APK, `apksigner verify`, 2 artifacts, `workflow_dispatch` |
| 8 | Sem como criar chave só pelo celular | Novo workflow `generate-keystore.yml` |
| 9 | `gradle-wrapper.properties` sem `networkTimeout`/validação | Adicionados |
| 10 | Debug e release com mesmo id (conflito de assinatura ao trocar) | Debug usa sufixo `.debug` |
| 11 | `lint` poderia derrubar o `assembleRelease` | `abortOnError false` / `checkReleaseBuilds false` (rode `lint` à parte para avisos) |
| 12 | **Arquivo ausente:** o jogo pede `models/bruh_im_dead.glb` (monstro), que **não está no ZIP**; dá 404 e cai no monstro procedural | Criada `assets/www/models/` (+LEIA-ME) e `glb` sem compressão; **você precisa colocar o arquivo `bruh_im_dead.glb` ali** |

## Pontos de atenção (não alterados)
- **89 `<canvas>`** no DOM e vários `WebGLRenderer` (menu, inspeção de arma, pets, personagens) além do renderer da partida: em celular de 6 GB pode pesar na RAM. Não mexi para não alterar o jogo; medir em aparelho real antes de otimizar.
- Qualidade gráfica: o jogo já escolhe o preset por benchmark (núcleos, RAM, FPS; celular recebe penalidade) e tem Muito baixo→Ultra; nada força Ultra. Pixel ratio no toque limitado a 1,5.
- HTML de 18 MB com mídia em base64: primeira abertura pode demorar alguns segundos.
- Multiplayer: usa `WebSocket` para um servidor externo (`server.js`, não incluído). O app permite `ws://` (cleartext e conteúdo misto liberados), mas isso **não foi testado**.

## Recursos preservados
`index.html` do jogo **não foi modificado** nesta etapa (só `tools/make_index.py` o gerava antes): todos os mapas, armas, skins, personagens/modelos 3D, pets, bots e dificuldades, modos de jogo, multiplayer, mira (incl. mira assistida do gamepad), os 6 presets gráficos, áudio, menus e salvamentos continuam exatamente como no ZIP recebido. Nenhuma funcionalidade foi removida.

## Gamepad (mapa real do código, ver `GAMEPAD.md`)
Leitura nativa: eixos X/Y (esquerdo), Z/RZ ou RX/RY (direito), gatilhos LTRIGGER/BRAKE e RTRIGGER/GAS, hat D-pad, botões A/B/X/Y/L1/R1/L2/R2/Select/Start/L3/R3/Mode. Xbox/PlayStation/genéricos usam essas mesmas rotas; a distinção Xbox×PS (dicas ✕○□△) está na regex corrigida. **Não testado com controle físico.**
