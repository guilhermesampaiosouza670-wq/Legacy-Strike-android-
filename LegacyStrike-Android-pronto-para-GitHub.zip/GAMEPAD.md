# Gamepad — funções reais do jogo (extraídas do código)

O app lê o controle Bluetooth de duas formas: pela Gamepad API do WebView e, se ela não detectar o controle,
por um leitor nativo (`MainActivity`) que entrega os botões no padrão *standard* (A=0, B=1, X=2, Y=3, LB=4, RB=5, LT=6, RT=7,
Select=8, Start=9, L3=10, R3=11, D-pad=12–15). Zona morta e sensibilidade: ⚙ > Gamepad (do jogo).

## Durante a partida
| Controle | Função |
|---|---|
| Analógico esquerdo | Mover |
| Analógico direito | Câmera (sensibilidade H/V no ⚙) |
| RT | Atirar |
| LT | Mirar / zoom |
| A | Pular |
| X | Recarregar |
| Y | Trocar arma |
| B | Inspecionar |
| LB | Granada |
| RB (segurar) | Interagir (E) — C4, resgates etc. |
| L3 | Correr (Shift) |
| D-pad ↑ / ← / ↓ | Arma principal / pistola / faca (R3 também pega a faca) |
| D-pad → | Soltar arma (ou próximo jogador se estiver morto) |
| Select/View | Abrir/fechar loja de compra |
| Start/Menu | Pausar |
Os botões podem ser remapeados em ⚙ > Gamepad; a barra de dicas mostra os nomes reais (✕○□△ para PlayStation, ABXY para Xbox).

## Menus e loja (mouse virtual)
| Controle | Função |
|---|---|
| Analógico esquerdo ou direito | Move o cursor (aparece sozinho ao abrir um menu) |
| A | Clica |
| B | Voltar / fechar |
| D-pad | Pula de botão em botão (o cursor acompanha) |
| LB / RB | Trocar de aba do menu |
| LT / RT | Rolar listas |
| L3 (segurado) | Cursor lento |
| R3 | Liga/desliga o mouse virtual |
