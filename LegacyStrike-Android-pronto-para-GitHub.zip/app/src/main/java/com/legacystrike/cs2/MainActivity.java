package com.legacystrike.cs2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.util.Log;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Legacy Strike CS2 — casca Android. O jogo roda 100% offline a partir de assets/www,
 * servido em https://appassets.androidplatform.net (origem estável => localStorage persistente).
 */
public class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private static final String TAG = "LegacyStrike";
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";
    private static final int REQ_FILE = 4001, REQ_SAVE = 4002;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private byte[] pendingSave;
    private long lastBack = 0;

    /* ---------- gamepad nativo (lido pelo JS via LSAndroid.padState) ---------- */
    private final Object padLock = new Object();
    private final float[] axes = new float[4];
    private final float[] btn = new float[17];
    private float hatX = 0, hatY = 0;
    private boolean padConnected = false;
    private boolean padDirty = true;
    private String padCache = null;
    private String padId = "Gamepad (STANDARD GAMEPAD)";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().setBackgroundDrawableResource(android.R.color.black);

        final boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        if (debuggable) WebView.setWebContentsDebuggingEnabled(true);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); // servidor multiplayer ws:// opcional
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) || "blob".equals(u.getScheme()) || "data".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                // memória insuficiente / crash do renderer: recria a tela em vez de fechar o app
                Log.w(TAG, "renderer gone, recriando");
                runOnUiThread(() -> recreate());
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                if (debuggable) Log.d(TAG, m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "LSAndroid");

        InputManager im = (InputManager) getSystemService(Context.INPUT_SERVICE);
        if (im != null) im.registerInputDeviceListener(this, null);
        refreshPad();

        // restoreState devolve null quando não há histórico utilizável (ex.: recreate() após o renderer morrer):
        // nesse caso carrega a URL inicial, senão a tela ficaria preta.
        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) web.loadUrl(START_URL);
    }

    /* ---------- ponte JS <-> Java ---------- */
    private class Bridge {
        @JavascriptInterface
        public String getBackup() {
            try {
                File f = new File(getFilesDir(), "ls_backup.json");
                if (!f.exists()) return "";
                try (InputStream in = new FileInputStream(f)) {
                    byte[] b = new byte[(int) f.length()];
                    int n = 0;
                    while (n < b.length) { int r = in.read(b, n, b.length - n); if (r < 0) break; n += r; }
                    return new String(b, 0, n, StandardCharsets.UTF_8);
                }
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void saveBackup(String json) {
            try {
                File tmp = new File(getFilesDir(), "ls_backup.tmp");
                try (OutputStream o = new FileOutputStream(tmp)) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
                File dst = new File(getFilesDir(), "ls_backup.json");
                if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
            } catch (Exception e) { Log.w(TAG, "backup falhou", e); }
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                pendingSave = Base64.decode(base64, Base64.DEFAULT);
                final String n = name, m = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(m);
                    i.putExtra(Intent.EXTRA_TITLE, n);
                    try { startActivityForResult(i, REQ_SAVE); }
                    catch (ActivityNotFoundException e) { toast("Nenhum gerenciador de arquivos disponível"); }
                });
            } catch (Exception e) { toast("Falha ao salvar arquivo"); }
        }

        @JavascriptInterface
        public void toast(String msg) { MainActivity.this.toast(msg); }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String padState() {
            synchronized (padLock) {
                if (!padConnected) return "";
                if (!padDirty && padCache != null) return padCache;
                StringBuilder sb = new StringBuilder(220);
                sb.append("{\"c\":1,\"id\":\"").append(padId.replace("\"", "")).append("\",\"axes\":[");
                for (int i = 0; i < 4; i++) { if (i > 0) sb.append(','); sb.append(String.format(Locale.US, "%.3f", axes[i])); }
                sb.append("],\"b\":[");
                for (int i = 0; i < 17; i++) {
                    float v = btn[i];
                    if (i == 14 && hatX < -0.5f) v = 1;
                    if (i == 15 && hatX > 0.5f) v = 1;
                    if (i == 12 && hatY < -0.5f) v = 1;
                    if (i == 13 && hatY > 0.5f) v = 1;
                    if (i > 0) sb.append(',');
                    sb.append(String.format(Locale.US, "%.2f", v));
                }
                sb.append("]}");
                padCache = sb.toString();
                padDirty = false;
                return padCache;
            }
        }

        @JavascriptInterface
        public String deviceInfo() {
            return Build.MANUFACTURER + " " + Build.MODEL + " / Android " + Build.VERSION.RELEASE;
        }
    }

    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); }

    /* ---------- gamepad: mapeamento Android -> padrão "standard" da Gamepad API ---------- */
    private static boolean isPadSource(int src) {
        return (src & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private static int keyToButton(int kc) {
        switch (kc) {
            case KeyEvent.KEYCODE_BUTTON_A: return 0;
            case KeyEvent.KEYCODE_BUTTON_B: return 1;
            case KeyEvent.KEYCODE_BUTTON_X: return 2;
            case KeyEvent.KEYCODE_BUTTON_Y: return 3;
            case KeyEvent.KEYCODE_BUTTON_L1: return 4;
            case KeyEvent.KEYCODE_BUTTON_R1: return 5;
            case KeyEvent.KEYCODE_BUTTON_L2: return 6;
            case KeyEvent.KEYCODE_BUTTON_R2: return 7;
            case KeyEvent.KEYCODE_BUTTON_SELECT: return 8;
            case KeyEvent.KEYCODE_BUTTON_START: return 9;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return 10;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: return 11;
            case KeyEvent.KEYCODE_DPAD_UP: return 12;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 13;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 14;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 15;
            case KeyEvent.KEYCODE_BUTTON_MODE: return 16;
            default: return -1;
        }
    }

    private void refreshPad() {
        boolean found = false;
        String id = null;
        for (int did : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(did);
            if (d != null && !d.isVirtual() && isPadSource(d.getSources())) {
                found = true;
                id = d.getName() + " (STANDARD GAMEPAD Vendor: " + String.format("%04x", d.getVendorId())
                        + " Product: " + String.format("%04x", d.getProductId()) + ")";
                break;
            }
        }
        synchronized (padLock) {
            padConnected = found;
            padDirty = true;
            if (id != null) padId = id;
            if (!found) {
                java.util.Arrays.fill(axes, 0);
                java.util.Arrays.fill(btn, 0);
                hatX = hatY = 0;
            }
        }
    }

    @Override public void onInputDeviceAdded(int i) { refreshPad(); }
    @Override public void onInputDeviceRemoved(int i) { refreshPad(); }
    @Override public void onInputDeviceChanged(int i) { refreshPad(); }

    private static float dead(float v) { return Math.abs(v) < 0.04f ? 0f : v; }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (isPadSource(e.getSource()) && e.getAction() == MotionEvent.ACTION_MOVE) {
            synchronized (padLock) {
                padConnected = true;
                padDirty = true;
                axes[0] = dead(e.getAxisValue(MotionEvent.AXIS_X));
                axes[1] = dead(e.getAxisValue(MotionEvent.AXIS_Y));
                // analógico direito: Z/RZ (Xbox, PS, maioria); alguns usam RX/RY
                float rx = e.getAxisValue(MotionEvent.AXIS_Z), ry = e.getAxisValue(MotionEvent.AXIS_RZ);
                if (Math.abs(rx) < 0.04f && Math.abs(ry) < 0.04f) {
                    rx = e.getAxisValue(MotionEvent.AXIS_RX);
                    ry = e.getAxisValue(MotionEvent.AXIS_RY);
                }
                axes[2] = dead(rx);
                axes[3] = dead(ry);
                float lt = Math.max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE));
                float rt = Math.max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS));
                btn[6] = Math.max(lt, keyHeld[6] ? 1f : 0f);
                btn[7] = Math.max(rt, keyHeld[7] ? 1f : 0f);
                hatX = e.getAxisValue(MotionEvent.AXIS_HAT_X);
                hatY = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            }
            return true;
        }
        return super.dispatchGenericMotionEvent(e);
    }

    private final boolean[] keyHeld = new boolean[17];

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int src = e.getSource();
        int kc = e.getKeyCode();
        boolean dpadKey = kc >= KeyEvent.KEYCODE_DPAD_UP && kc <= KeyEvent.KEYCODE_DPAD_RIGHT;
        boolean pad = isPadSource(src)
                || (dpadKey && e.getDevice() != null && isPadSource(e.getDevice().getSources()));
        if (pad) {
            int b = keyToButton(kc);
            if (b >= 0) {
                boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
                synchronized (padLock) {
                    padConnected = true;
                    padDirty = true;
                    keyHeld[b] = down;
                    btn[b] = down ? 1f : 0f;
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    /* ---------- ciclo de vida, Voltar, imersivo ---------- */
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        if (web != null) { web.onResume(); web.resumeTimers(); }
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.__lsBackground&&window.__lsBackground()", null);
            web.onPause();
            web.pauseTimers();
        }
        super.onPause();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // TRIM_MEMORY_RUNNING_LOW (10) ou pior: o jogo pode reduzir qualidade se implementar window.__lsLowMemory
        if (level >= 10 && web != null) web.evaluateJavascript("window.__lsLowMemory&&window.__lsLowMemory(" + level + ")", null);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.__lsBack?window.__lsBack():'exit')", v -> {
            if (v != null && v.contains("exit")) {
                long n = System.currentTimeMillis();
                if (n - lastBack < 2000) finish();
                else { lastBack = n; toast("Toque em Voltar novamente para sair"); }
            }
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
        } else if (req == REQ_SAVE) {
            if (res == RESULT_OK && data != null && data.getData() != null && pendingSave != null) {
                try (OutputStream o = getContentResolver().openOutputStream(data.getData())) {
                    if (o != null) { o.write(pendingSave); toast("Arquivo salvo"); }
                } catch (Exception e) { toast("Falha ao salvar arquivo"); }
            }
            pendingSave = null;
        }
    }

    @Override
    protected void onDestroy() {
        InputManager im = (InputManager) getSystemService(Context.INPUT_SERVICE);
        if (im != null) im.unregisterInputDeviceListener(this);
        if (web != null) { web.removeJavascriptInterface("LSAndroid"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
