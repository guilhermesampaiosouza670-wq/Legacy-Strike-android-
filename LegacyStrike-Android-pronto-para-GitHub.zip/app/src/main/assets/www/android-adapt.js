/* LEGACY STRIKE — camada de adaptação Android (WebView).
   Carregada ANTES de qualquer script do jogo. No navegador comum (sem a ponte nativa) só aplica
   o endurecimento de toque; no APK ativa: backup de progresso, tela cheia, áudio, gamepad nativo,
   botão Voltar e ciclo de vida. Não altera nenhuma regra do jogo. */
(function(){
'use strict';
var NA=!!window.LSAndroid,B=window.LSAndroid;
function safe(f){try{return f()}catch(e){}}

/* 1) Progresso: restaura backup nativo se o armazenamento do WebView estiver vazio e espelha as chaves */
if(NA){
  safe(function(){
    if(localStorage.length===0){
      var raw=B.getBackup();
      if(raw){var o=JSON.parse(raw);for(var k in o)localStorage.setItem(k,o[k])}
    }
  });
  var lastSig='';
  var backup=function(){safe(function(){
    var o={},sig=5381,n=localStorage.length;
    // assinatura com hash do conteúdo (antes só somava tamanhos e perdia mudanças do mesmo comprimento, ex.: "5" -> "6")
    for(var i=0;i<n;i++){var k=localStorage.key(i),v=localStorage.getItem(k)||'';o[k]=v;
      var t=k+'\u0001'+v;for(var j=0;j<t.length;j++)sig=((sig<<5)+sig+t.charCodeAt(j))|0}
    var s=n+':'+sig;if(s===lastSig)return;lastSig=s;B.saveBackup(JSON.stringify(o))})};
  document.addEventListener('visibilitychange',function(){if(document.hidden)backup()});
  addEventListener('pagehide',backup);
  setInterval(backup,45000);
}

/* 2) Tela cheia / orientação: o app já é imersivo e horizontal; o jogo recebe respostas de sucesso */
if(NA){
  safe(function(){
    var de=document.documentElement,ok=function(){return Promise.resolve()};
    var fire=function(){setTimeout(function(){document.dispatchEvent(new Event('fullscreenchange'));document.dispatchEvent(new Event('webkitfullscreenchange'))},0)};
    Object.defineProperty(document,'fullscreenElement',{get:function(){return de},configurable:true});
    Object.defineProperty(document,'webkitFullscreenElement',{get:function(){return de},configurable:true});
    Object.defineProperty(document,'fullscreenEnabled',{get:function(){return true},configurable:true});
    Element.prototype.requestFullscreen=function(){fire();return ok()};
    Element.prototype.webkitRequestFullscreen=Element.prototype.requestFullscreen;
    document.exitFullscreen=ok;document.webkitExitFullscreen=ok;
    if(screen.orientation){screen.orientation.lock=ok;screen.orientation.unlock=function(){}}
  });
}

/* 3) Áudio: retoma contextos suspensos no primeiro toque e suspende em segundo plano */
safe(function(){
  var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  var all=[];
  var LSAC=class extends AC{constructor(o){super(o);all.push(this)}};
  window.AudioContext=LSAC;if(window.webkitAudioContext)window.webkitAudioContext=LSAC;
  var wake=function(){all.forEach(function(c){if(c.state==='suspended'||c.state==='interrupted')c.resume().catch(function(){})})};
  ['pointerdown','touchend','keydown','click'].forEach(function(e){addEventListener(e,wake,true)});
  document.addEventListener('visibilitychange',function(){
    all.forEach(function(c){document.hidden?c.suspend().catch(function(){}):c.resume().catch(function(){})})});
});

/* 4) Toque: sem zoom, sem menu de contexto, sem seleção, sem pull-to-refresh, área de toque maior */
safe(function(){
  var st=document.createElement('style');st.id='lsa-touch';
  st.textContent='html,body{overscroll-behavior:none;-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;touch-action:manipulation}'
   +'body *:not(input):not(textarea):not([contenteditable]){-webkit-user-select:none;user-select:none}'
   +'canvas,#touch,#touch *,#hud{touch-action:none}'
   +'#touch .tbtn{touch-action:none}'
   ;
  (document.head||document.documentElement).appendChild(st);
  document.addEventListener('DOMContentLoaded',function(){safe(function(){var t=document.querySelector('.tbtn');
    if(t&&getComputedStyle(t).position!=='static')st.textContent+='.tbtn::before{content:"";position:absolute;inset:-9px;border-radius:inherit}'})});
  document.addEventListener('contextmenu',function(e){var t=e.target;if(!(t&&/^(INPUT|TEXTAREA)$/.test(t.tagName)))e.preventDefault()},true);
  ['gesturestart','gesturechange','gestureend'].forEach(function(e){document.addEventListener(e,function(ev){ev.preventDefault()},{passive:false})});
  addEventListener('webglcontextlost',function(e){e.preventDefault()},true);
  addEventListener('webglcontextrestored',function(){setTimeout(function(){dispatchEvent(new Event('resize'))},100)},true);
});

/* 5) Exportar progresso (blob/download) e outros downloads -> seletor de arquivo do Android */
if(NA){
  safe(function(){
    var send=function(url,name){
      fetch(url).then(function(r){return r.blob()}).then(function(b){
        var fr=new FileReader();fr.onload=function(){var s=String(fr.result),i=s.indexOf(',');B.saveFile(name||'legacy-strike.bin',b.type||'application/octet-stream',s.slice(i+1))};fr.readAsDataURL(b)})
        .catch(function(e){B.toast('Falha ao salvar arquivo')});
    };
    var click=HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click=function(){
      if(this.hasAttribute('download')&&/^(blob|data):/.test(this.href)){send(this.href,this.getAttribute('download'));return}
      return click.apply(this,arguments)};
    document.addEventListener('click',function(e){
      var a=e.target&&e.target.closest&&e.target.closest('a[download]');
      if(a&&/^(blob|data):/.test(a.href)){e.preventDefault();send(a.href,a.getAttribute('download'))}},true);
  });
}

/* 6) Gamepad Bluetooth: usa a Gamepad API do WebView quando existir; senão, controle nativo mapeado no padrão "standard" */
if(NA){
  safe(function(){
    var orig=navigator.getGamepads?navigator.getGamepads.bind(navigator):function(){return[]};
    var st=null,tt=0,pad=null,announced=false;
    function mk(s){
      var btn=function(v){return{pressed:v>.5,touched:v>.05,value:v}};
      return{id:s.id,index:0,connected:true,mapping:'standard',timestamp:performance.now(),axes:s.axes.slice(0,4),
        buttons:s.b.map(btn),
        vibrationActuator:{type:'dual-rumble',playEffect:function(t,p){B.vibrate(Math.min(400,(p&&p.duration)||60));return Promise.resolve('complete')},reset:function(){return Promise.resolve('complete')}}}
    }
    function poll(){
      var n=performance.now();if(n-tt<4&&pad)return pad;tt=n;
      var raw=safe(function(){return B.padState()});
      if(!raw){pad=null;announced=false;return null}
      st=JSON.parse(raw);pad=st.c?mk(st):null;
      if(pad&&!announced){announced=true;var ev=new Event('gamepadconnected');ev.gamepad=pad;setTimeout(function(){dispatchEvent(ev)},0)}
      if(!pad&&announced){announced=false;setTimeout(function(){dispatchEvent(new Event('gamepaddisconnected'))},0)}
      return pad;
    }
    navigator.getGamepads=function(){
      var real=safe(orig)||[];
      for(var i=0;i<real.length;i++)if(real[i]&&real[i].connected)return real;
      var p=poll();return p?[p,null,null,null]:real;
    };
    setInterval(poll,500); // detecta conexão/desconexão mesmo com o jogo parado
  });
}

/* 7) Botão Voltar e ciclo de vida (chamados pelo Java) */
window.__lsBack=function(){
  var q=function(s){return document.querySelector(s)};
  var click=function(el){if(!el)return false;['pointerdown','mousedown','touchstart','pointerup','mouseup','touchend','click'].forEach(function(t){
    var ev;try{ev=(t[0]==='t')?new Event(t,{bubbles:true,cancelable:true}):(t[0]==='p'?new PointerEvent(t,{bubbles:true,cancelable:true,pointerType:'touch'}):new MouseEvent(t,{bubbles:true,cancelable:true,view:window}))}catch(e){return}
    el.dispatchEvent(ev)});return true};
  if(q('#lsx.show')){click(q('#lsxX'));return 'ok'}
  if(q('#crOpen.show #crClose')){click(q('#crClose'));return 'ok'}
  if(q('#menu.show')){
    var home=q('#mnav [data-tab=home]');
    if(home&&!home.classList.contains('sel')){click(home);return 'ok'}
    return 'exit';
  }
  if(q('#pause.show'))return 'exit';
  if(q('#buy.show')){document.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyB',key:'b',bubbles:true}));return 'ok'}
  var bp=q('#bPause');
  if(bp){ // o jogo trata o toque em #touch com TouchEvent real
    try{var r=bp.getBoundingClientRect(),mk=function(){return new Touch({identifier:9001,target:bp,clientX:r.left+r.width/2||5,clientY:r.top+r.height/2||5})};
      bp.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,cancelable:true,touches:[mk()],targetTouches:[mk()],changedTouches:[mk()]}));
      bp.dispatchEvent(new TouchEvent('touchend',{bubbles:true,cancelable:true,touches:[],targetTouches:[],changedTouches:[mk()]}));
      return 'ok'}catch(e){}
  }
  return 'exit';
};
window.__lsBackground=function(){
  var p=document.querySelector('#pause'),m=document.querySelector('#menu.show');
  if(m||(p&&p.classList.contains('show')))return;
  var b=document.querySelector('#bPause');if(b)window.__lsBack();
};
})();
